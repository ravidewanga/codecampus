var utils = require('./utils.js');

console.log(utils.simpleInterest(100,2,10));