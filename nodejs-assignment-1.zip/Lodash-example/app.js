var utils = require('./utils.js');

console.log(utils.data.contact);

console.log(utils.data.drop);
console.log(utils.data.indexOf);
console.log(utils.data.multiply);
