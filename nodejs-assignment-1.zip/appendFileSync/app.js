const fs = require('fs');

fs.appendFileSync('test.txt','Hello Ravi\n');